import { SwipeLayoutBase } from './swipe-layout.common';
export declare class SwipeLayout extends SwipeLayoutBase {
    private _androidViewId;
    readonly android: any;
    createNativeView(): any;
    initNativeView(): void;
}

export declare enum ANIMATION_STATE {
    ALWAYS = 0,
    ON_EVENTS = 1,
    NEVER = 2,
}
export declare enum GESTURE_MODE {
    DRAG = 0,
    SWIPE = 1,
}
